#include <iostream>
#include "Menue.h"



using namespace std;

int main()
{
    Menue meinMenue;
    meinMenue.start();
    return 0;
}
